var request = new XMLHttpRequest();

request.open('POST', 'https://api.kairos.com/recognize');

request.setRequestHeader('Content-Type', 'application/json');
request.setRequestHeader('app_id', '4985f625');
request.setRequestHeader('app_key', 'aa9e5d2ec3b00306b2d9588c3a25d68e');

request.onreadystatechange = function () {
  if (this.readyState === 4) {
    console.log('Status:', this.status);
    console.log('Headers:', this.getAllResponseHeaders());
    console.log('Body:', this.responseText);
  }
};

var body = {
  'image': 'http://cdn2.stylecraze.com/wp-content/uploads/2013/06/15-Pictures-Of-Aishwarya-Rai-Without-Makeup-1.jpg',
  'gallery_name': 'MyGallery'
};

request.send(JSON.stringify(body));
