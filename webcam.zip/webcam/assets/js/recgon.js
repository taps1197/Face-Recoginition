var request = new XMLHttpRequest();

request.open('POST', 'https://api.kairos.com/recognize');

request.setRequestHeader('Content-Type', 'application/json');
request.setRequestHeader('app_id', '4985f625');
request.setRequestHeader('app_key', 'aa9e5d2ec3b00306b2d9588c3a25d68e');

request.onreadystatechange = function () {
  if (this.readyState === 4) {
    console.log('Status:', this.status);
    console.log('Headers:', this.getAllResponseHeaders());
    console.log('Body:', this.responseText);
  }
};

var body = {
  'image': 'http://media.kairos.com/kairos-elizabeth.jpg',
  'gallery_name': 'MyGallery'
};

request.send(JSON.stringify(body));
