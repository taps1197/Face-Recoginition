    var request = new XMLHttpRequest();

    request.open('POST', 'https://api.kairos.com/enroll');

    request.setRequestHeader('Content-Type', 'application/json');
    request.setRequestHeader('app_id', '7bad4f1e');
    request.setRequestHeader('app_key', 'd2327a207d61c6298b49b33692f476e4');

    request.onreadystatechange = function () {
      if (this.readyState === 4) {
        console.log('Status:', this.status);
        console.log('Headers:', this.getAllResponseHeaders());
        console.log('Body:', this.responseText);
      }
    };

    var body = {
      'image': 'https://static.toiimg.com/photo/61216758.cms',
      'subject_id': 'Aish',
      'gallery_name': 'MyGallery'
    };

    request.send(JSON.stringify(body));
